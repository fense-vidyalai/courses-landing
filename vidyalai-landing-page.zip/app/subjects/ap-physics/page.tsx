import Image from "next/image"
import type { Metadata } from "next"
import { Button } from "@/components/ui/button"
import { Check, ArrowRight, Atom } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Testimonials } from "@/components/testimonials"
import { FinalCTA } from "@/components/final-cta"

export const metadata: Metadata = {
  title: "AP Physics Tutoring | Vidyalai",
  description:
    "Expert AP Physics tutoring to help students master physics principles and excel in their AP Physics exams.",
}

export default function APPhysics() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full bg-white pt-6 pb-8 md:py-16 lg:py-20 overflow-hidden">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="flex flex-col justify-center space-y-4 order-2 lg:order-1 lg:pr-8">
                <div className="inline-flex items-center justify-center rounded-full bg-primary/10 px-3 py-1 md:px-4 md:py-1.5 text-xs md:text-sm font-medium text-primary mb-2">
                  <span>AP Physics</span>
                </div>
                <div className="space-y-3">
                  <h1 className="text-3xl font-extrabold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl text-black">
                    Master <span className="text-primary">AP Physics</span> With Expert Tutoring
                  </h1>
                  <p className="text-lg md:text-xl text-text-secondary font-medium">
                    Understand complex physics principles and excel in your AP Physics exam with our specialized
                    tutoring
                  </p>
                </div>

                <div className="flex flex-col space-y-2 mt-2">
                  <div className="flex items-center">
                    <Check className="mr-2 h-5 w-5 text-primary" />
                    <span className="text-black font-medium">Comprehensive coverage of all AP Physics courses</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="mr-2 h-5 w-5 text-primary" />
                    <span className="text-black font-medium">Expert tutors with physics research experience</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="mr-2 h-5 w-5 text-primary" />
                    <span className="text-black font-medium">Practice with real AP Physics exam questions</span>
                  </div>
                </div>

                <div className="mt-6">
                  <Button className="h-12 px-8 bg-primary hover:bg-primary-dark text-white transition-all duration-300 transform hover:scale-105 font-medium">
                    Request AP Physics Lesson
                  </Button>
                </div>
              </div>

              <div className="order-1 lg:order-2 flex justify-center lg:justify-end">
                <div className="relative w-full rounded-lg shadow-lg overflow-hidden bg-[#0a1e3c]">
                  <div className="hidden md:block relative w-full aspect-[4/5]">
                    <Image
                      src="/placeholder.svg?height=600&width=500"
                      alt="Student studying AP Physics with laboratory equipment"
                      fill
                      className="object-cover"
                      sizes="(max-width: 1024px) 50vw, 600px"
                      priority
                    />
                  </div>
                  <div className="block md:hidden relative w-full aspect-[16/9]">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Student studying AP Physics with laboratory equipment"
                      fill
                      className="object-cover"
                      sizes="100vw"
                      priority
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Course Overview */}
        <section className="w-full py-12 md:py-16 lg:py-20 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center text-center space-y-3 mb-8 md:mb-10">
              <div className="inline-flex items-center justify-center rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <span>Course Overview</span>
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-extrabold tracking-tighter sm:text-4xl text-black">
                  AP Physics Curriculum
                </h2>
                <p className="text-lg text-text-secondary max-w-[800px] mx-auto">
                  AP Physics includes several course options that explore the principles of physics through
                  inquiry-based investigations, focusing on concepts like mechanics, electricity, magnetism, and more.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <Atom className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-black mb-3">AP Physics Course Options</h3>
                <ul className="space-y-4 text-text-secondary">
                  <li>
                    <h4 className="font-bold text-black">AP Physics 1: Algebra-Based</h4>
                    <p>
                      Covers Newtonian mechanics, work, energy, power, mechanical waves, sound, and simple circuits.
                    </p>
                  </li>
                  <li>
                    <h4 className="font-bold text-black">AP Physics 2: Algebra-Based</h4>
                    <p>Covers fluid mechanics, thermodynamics, electricity, magnetism, optics, and quantum physics.</p>
                  </li>
                  <li>
                    <h4 className="font-bold text-black">AP Physics C: Mechanics</h4>
                    <p>
                      Covers kinematics, Newton's laws, work, energy, power, linear momentum, circular motion, rotation,
                      oscillations, and gravitation using calculus.
                    </p>
                  </li>
                  <li>
                    <h4 className="font-bold text-black">AP Physics C: Electricity and Magnetism</h4>
                    <p>
                      Covers electrostatics, conductors, capacitors, dielectrics, electric circuits, magnetic fields,
                      and electromagnetism using calculus.
                    </p>
                  </li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-black mb-3">AP Physics Exam Structure</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-bold text-black">AP Physics 1 & 2</h4>
                    <p className="text-text-secondary font-medium">Section I: Multiple Choice</p>
                    <p className="text-text-secondary">50 questions | 1 hour 30 minutes | 50% of exam score</p>
                    <p className="text-text-secondary font-medium mt-2">Section II: Free Response</p>
                    <p className="text-text-secondary">5 questions | 1 hour 30 minutes | 50% of exam score</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-black">AP Physics C (Both Exams)</h4>
                    <p className="text-text-secondary font-medium">Section I: Multiple Choice</p>
                    <p className="text-text-secondary">35 questions | 45 minutes | 50% of exam score</p>
                    <p className="text-text-secondary font-medium mt-2">Section II: Free Response</p>
                    <p className="text-text-secondary">3 questions | 45 minutes | 50% of exam score</p>
                  </div>

                  <div className="pt-2">
                    <p className="text-text-secondary">
                      The exams test your understanding of the physics concepts covered in the courses, as well as your
                      ability to:
                    </p>
                    <ul className="mt-2 space-y-1 text-text-secondary">
                      <li>• Apply mathematical routines to physics principles</li>
                      <li>• Design and analyze experiments</li>
                      <li>• Explain and predict physical phenomena</li>
                      <li>• Interpret models and representations</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose Vidyalai for AP Physics */}
        <section className="w-full py-12 md:py-16 lg:py-20 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center text-center space-y-3 mb-8 md:mb-10">
              <div className="inline-flex items-center justify-center rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <span>Why Choose Us</span>
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-extrabold tracking-tighter sm:text-4xl text-black">
                  Why Choose Vidyalai for AP Physics
                </h2>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
                <h3 className="text-xl font-bold text-black mb-3">Expert Physics Tutors</h3>
                <p className="text-text-secondary">
                  Our tutors have advanced degrees in physics and years of experience teaching AP Physics concepts. Many
                  have research experience in physical sciences and engineering.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
                <h3 className="text-xl font-bold text-black mb-3">Problem-Solving Focus</h3>
                <p className="text-text-secondary">
                  We emphasize developing strong problem-solving skills, teaching you systematic approaches to tackle
                  even the most challenging physics problems on the AP exam.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
                <h3 className="text-xl font-bold text-black mb-3">Personalized Learning</h3>
                <p className="text-text-secondary">
                  We tailor our tutoring to address your specific challenges, whether it's understanding mechanics,
                  electricity, magnetism, or calculus applications in physics.
                </p>
              </div>
            </div>

            <div className="flex justify-center mt-10">
              <Button className="h-12 px-8 bg-primary hover:bg-primary-dark text-white transition-all duration-300 transform hover:scale-105 font-medium">
                Find Your AP Physics Tutor
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="w-full py-12 md:py-16 lg:py-20 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center text-center space-y-3 mb-8 md:mb-10">
              <div className="space-y-2">
                <h2 className="text-3xl font-extrabold tracking-tighter sm:text-4xl text-black">
                  Frequently Asked Questions
                </h2>
              </div>
            </div>

            <div className="max-w-3xl mx-auto space-y-4">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-bold text-black mb-2">Which AP Physics course should I take?</h3>
                <p className="text-text-secondary">
                  The choice depends on your academic goals and math background. AP Physics 1 and 2 are algebra-based
                  and suitable for most students. AP Physics C courses use calculus and are ideal for students planning
                  to major in physics, engineering, or related fields. Our advisors can help you choose the right
                  course.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-bold text-black mb-2">How difficult are the AP Physics courses?</h3>
                <p className="text-text-secondary">
                  AP Physics courses are considered challenging, requiring strong mathematical skills and conceptual
                  understanding. AP Physics C courses are particularly demanding due to their calculus requirements. Our
                  expert tutors break down complex topics and provide structured support to make the material more
                  accessible.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-bold text-black mb-2">Do I need to be good at math for AP Physics?</h3>
                <p className="text-text-secondary">
                  Yes, strong math skills are important for success in AP Physics. For AP Physics 1 and 2, you should be
                  comfortable with algebra and trigonometry. For AP Physics C courses, calculus knowledge is required.
                  Our tutors can help strengthen both your math and physics skills.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-bold text-black mb-2">How can Vidyalai help with AP Physics labs?</h3>
                <p className="text-text-secondary">
                  Our tutors provide guidance on all required AP Physics laboratory investigations, helping you
                  understand experimental design, data collection, and analysis. We focus on developing the scientific
                  skills needed for success in both the lab and exam components.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials specific to AP Physics */}
        <Testimonials />

        {/* Final CTA */}
        <FinalCTA />
      </main>
      <Footer />
    </div>
  )
}
