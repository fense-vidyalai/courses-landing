import Image from "next/image"
import type { Metadata } from "next"
import { Button } from "@/components/ui/button"
import { Check, ArrowRight, MicroscopeIcon } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Testimonials } from "@/components/testimonials"
import { FinalCTA } from "@/components/final-cta"

export const metadata: Metadata = {
  title: "AP Biology Tutoring | Vidyalai",
  description:
    "Expert AP Biology tutoring to help students master complex biological concepts and excel in their AP Biology exam.",
}

export default function APBiology() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full bg-white pt-6 pb-8 md:py-16 lg:py-20 overflow-hidden">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="flex flex-col justify-center space-y-4 order-2 lg:order-1 lg:pr-8">
                <div className="inline-flex items-center justify-center rounded-full bg-primary/10 px-3 py-1 md:px-4 md:py-1.5 text-xs md:text-sm font-medium text-primary mb-2">
                  <span>AP Biology</span>
                </div>
                <div className="space-y-3">
                  <h1 className="text-3xl font-extrabold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl text-black">
                    Master <span className="text-primary">AP Biology</span> With Expert Tutoring
                  </h1>
                  <p className="text-lg md:text-xl text-text-secondary font-medium">
                    Understand complex biological concepts and excel in your AP Biology exam with our specialized
                    tutoring
                  </p>
                </div>

                <div className="flex flex-col space-y-2 mt-2">
                  <div className="flex items-center">
                    <Check className="mr-2 h-5 w-5 text-primary" />
                    <span className="text-black font-medium">Comprehensive coverage of all AP Biology units</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="mr-2 h-5 w-5 text-primary" />
                    <span className="text-black font-medium">Expert tutors with biology research experience</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="mr-2 h-5 w-5 text-primary" />
                    <span className="text-black font-medium">Practice with real AP Biology exam questions</span>
                  </div>
                </div>

                <div className="mt-6">
                  <Button className="h-12 px-8 bg-primary hover:bg-primary-dark text-white transition-all duration-300 transform hover:scale-105 font-medium">
                    Request AP Biology Lesson
                  </Button>
                </div>
              </div>

              <div className="order-1 lg:order-2 flex justify-center lg:justify-end">
                <div className="relative w-full rounded-lg shadow-lg overflow-hidden bg-[#0a1e3c]">
                  <div className="hidden md:block relative w-full aspect-[4/5]">
                    <Image
                      src="/placeholder.svg?height=600&width=500"
                      alt="Student studying AP Biology with microscope"
                      fill
                      className="object-cover"
                      sizes="(max-width: 1024px) 50vw, 600px"
                      priority
                    />
                  </div>
                  <div className="block md:hidden relative w-full aspect-[16/9]">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Student studying AP Biology with microscope"
                      fill
                      className="object-cover"
                      sizes="100vw"
                      priority
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Course Overview */}
        <section className="w-full py-12 md:py-16 lg:py-20 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center text-center space-y-3 mb-8 md:mb-10">
              <div className="inline-flex items-center justify-center rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <span>Course Overview</span>
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-extrabold tracking-tighter sm:text-4xl text-black">
                  AP Biology Curriculum
                </h2>
                <p className="text-lg text-text-secondary max-w-[800px] mx-auto">
                  AP Biology is an introductory college-level biology course where students cultivate their
                  understanding of biology through inquiry-based investigations.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <MicroscopeIcon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-black mb-3">Course Units</h3>
                <ul className="space-y-2 text-text-secondary">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                    <span>Unit 1: Chemistry of Life</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                    <span>Unit 2: Cell Structure and Function</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                    <span>Unit 3: Cellular Energetics</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                    <span>Unit 4: Cell Communication and Cell Cycle</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                    <span>Unit 5: Heredity</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                    <span>Unit 6: Gene Expression and Regulation</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                    <span>Unit 7: Natural Selection</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                    <span>Unit 8: Ecology</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-black mb-3">AP Biology Exam Structure</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-bold text-black">Section I: Multiple Choice</h4>
                    <p className="text-text-secondary">60 questions | 1 hour 30 minutes | 50% of exam score</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-black">Section II: Free Response</h4>
                    <p className="text-text-secondary">6 questions | 1 hour 30 minutes | 50% of exam score</p>
                    <ul className="mt-2 space-y-1 text-text-secondary">
                      <li>• 2 long free-response questions</li>
                      <li>• 4 short free-response questions</li>
                    </ul>
                  </div>
                  <div className="pt-2">
                    <p className="text-text-secondary">
                      The exam tests your understanding of the biological concepts covered in the course units, as well
                      as your ability to:
                    </p>
                    <ul className="mt-2 space-y-1 text-text-secondary">
                      <li>• Design and describe experiments</li>
                      <li>• Analyze data and evaluate evidence</li>
                      <li>• Apply mathematical routines</li>
                      <li>• Make connections between concepts</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose Vidyalai for AP Biology */}
        <section className="w-full py-12 md:py-16 lg:py-20 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center text-center space-y-3 mb-8 md:mb-10">
              <div className="inline-flex items-center justify-center rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <span>Why Choose Us</span>
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-extrabold tracking-tighter sm:text-4xl text-black">
                  Why Choose Vidyalai for AP Biology
                </h2>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
                <h3 className="text-xl font-bold text-black mb-3">Expert Biology Tutors</h3>
                <p className="text-text-secondary">
                  Our tutors have advanced degrees in biology and years of experience teaching AP Biology concepts. Many
                  have research experience in biological sciences.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
                <h3 className="text-xl font-bold text-black mb-3">Comprehensive Lab Support</h3>
                <p className="text-text-secondary">
                  Get help understanding and analyzing the required AP Biology laboratory investigations, with guidance
                  on experimental design and data analysis.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
                <h3 className="text-xl font-bold text-black mb-3">Personalized Learning</h3>
                <p className="text-text-secondary">
                  We tailor our tutoring to address your specific challenges, whether it's understanding cellular
                  processes, genetics, or ecological relationships.
                </p>
              </div>
            </div>

            <div className="flex justify-center mt-10">
              <Button className="h-12 px-8 bg-primary hover:bg-primary-dark text-white transition-all duration-300 transform hover:scale-105 font-medium">
                Find Your AP Biology Tutor
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="w-full py-12 md:py-16 lg:py-20 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center text-center space-y-3 mb-8 md:mb-10">
              <div className="space-y-2">
                <h2 className="text-3xl font-extrabold tracking-tighter sm:text-4xl text-black">
                  Frequently Asked Questions
                </h2>
              </div>
            </div>

            <div className="max-w-3xl mx-auto space-y-4">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-bold text-black mb-2">How difficult is AP Biology?</h3>
                <p className="text-text-secondary">
                  AP Biology is considered moderately difficult, requiring strong critical thinking skills and the
                  ability to apply biological concepts to new scenarios. With our expert tutoring, we help break down
                  complex topics into manageable parts.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-bold text-black mb-2">What score do I need to get college credit?</h3>
                <p className="text-text-secondary">
                  Most colleges award credit for scores of 3 or higher, though more selective institutions may require a
                  4 or 5. Our tutors help you aim for the highest possible score based on your target colleges.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-bold text-black mb-2">How can Vidyalai help with AP Biology labs?</h3>
                <p className="text-text-secondary">
                  Our tutors provide guidance on all required AP Biology laboratory investigations, helping you
                  understand experimental design, data collection, and analysis. We focus on developing the scientific
                  skills needed for success.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-bold text-black mb-2">When should I start AP Biology tutoring?</h3>
                <p className="text-text-secondary">
                  We recommend starting early in the school year to build a strong foundation, but our tutors can help
                  at any point in your AP Biology journey, including focused exam prep in the months leading up to the
                  AP test.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials specific to AP Biology */}
        <Testimonials />

        {/* Final CTA */}
        <FinalCTA />
      </main>
      <Footer />
    </div>
  )
}
