"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useMobile } from "@/hooks/use-mobile"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const isMobile = useMobile()

  return (
    <>
      <header className="w-full bg-white border-b border-gray-100">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center">
            <div className="relative h-8 w-8 md:h-9 md:w-9">
              <Image src="/images/vidyalai-logo-transparent.png" alt="Vidyalai Logo" fill className="object-contain" />
            </div>
            <span className="text-base md:text-lg font-extrabold text-black ml-1.5">Vidyalai</span>
          </Link>
          <nav className="hidden md:flex md:gap-10 ml-8">
            <Link
              href="#about"
              className="text-base font-medium text-black hover:text-primary transition-colors smooth-scroll"
            >
              About
            </Link>
            <Link
              href="#subjects"
              className="text-base font-medium text-black hover:text-primary transition-colors smooth-scroll"
            >
              Subjects
            </Link>
            <Link
              href="#tutors"
              className="text-base font-medium text-black hover:text-primary transition-colors smooth-scroll"
            >
              Tutors
            </Link>
            <Link
              href="#pricing"
              className="text-base font-medium text-black hover:text-primary transition-colors smooth-scroll"
            >
              Pricing
            </Link>
            <Link
              href="#contact"
              className="text-base font-medium text-black hover:text-primary transition-colors smooth-scroll"
            >
              Contact
            </Link>
          </nav>
          <div className="hidden md:block">
            <Button className="rounded-md bg-primary text-white px-6 py-2 h-10 text-base font-medium hover:bg-primary-dark transition-all duration-300 transform hover:scale-105">
              Request Lesson
            </Button>
          </div>
          <button
            className="block md:hidden text-black p-1 touch-manipulation"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
        {isMenuOpen && (
          <div className="container py-4 bg-white md:hidden border-t border-gray-100">
            <nav className="flex flex-col space-y-4">
              <Link
                href="#about"
                className="text-base font-medium text-black hover:text-primary transition-colors py-2 touch-manipulation smooth-scroll"
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </Link>
              <Link
                href="#subjects"
                className="text-base font-medium text-black hover:text-primary transition-colors py-2 touch-manipulation smooth-scroll"
                onClick={() => setIsMenuOpen(false)}
              >
                Subjects
              </Link>
              <Link
                href="#tutors"
                className="text-base font-medium text-black hover:text-primary transition-colors py-2 touch-manipulation smooth-scroll"
                onClick={() => setIsMenuOpen(false)}
              >
                Tutors
              </Link>
              <Link
                href="#pricing"
                className="text-base font-medium text-black hover:text-primary transition-colors py-2 touch-manipulation smooth-scroll"
                onClick={() => setIsMenuOpen(false)}
              >
                Pricing
              </Link>
              <Link
                href="#contact"
                className="text-base font-medium text-black hover:text-primary transition-colors py-2 touch-manipulation smooth-scroll"
                onClick={() => setIsMenuOpen(false)}
              >
                Contact
              </Link>
              <Button
                className="w-full rounded-md bg-primary text-white px-3 py-2 text-base font-medium mt-2 hover:bg-primary-dark transition-all duration-300 transform hover:scale-105"
                onClick={() => setIsMenuOpen(false)}
              >
                Request Lesson
              </Button>
            </nav>
          </div>
        )}
      </header>

      {/* Mobile Sticky CTA - Original version with accent color */}
      {isMobile && (
        <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 p-3 flex items-center justify-between">
          <div className="flex items-center">
            <div className="bg-primary/10 p-2 rounded-full mr-2">
              <Phone className="h-4 w-4 text-primary" />
            </div>
            <div>
              <p className="text-xs text-gray-500">Need help?</p>
              <p className="text-xs font-bold text-black">Call us now</p>
            </div>
          </div>
          <Button className="bg-primary text-white px-4 py-2 h-10 text-sm transition-all duration-300 transform hover:scale-105 hover:bg-primary-dark">
            Request Lesson
          </Button>
        </div>
      )}
    </>
  )
}
