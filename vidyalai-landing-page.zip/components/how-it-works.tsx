import { ClipboardList, Users, BookOpen } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function HowItWorks() {
  return (
    <section className="w-full bg-white py-8 md:py-12 border-t border-gray-100" id="about">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-8 md:mb-10">
          <h2 className="text-3xl md:text-4xl font-extrabold text-black mb-2 md:mb-3">How Vidyalai Works</h2>
        </div>

        <div className="mx-auto grid max-w-4xl grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {/* Step 1 */}
          <Card className="flex flex-col items-center text-center p-6 border border-gray-200 shadow-sm hover:shadow-md transition-all duration-300 bg-white h-full">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mb-4">
              <ClipboardList className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-primary mb-3">Step 1: Personalized Plan</h3>
            <p className="text-sm text-text-secondary">
              We assess strengths, challenges, and goals to craft a tailored AP prep plan.
            </p>
          </Card>

          {/* Step 2 */}
          <Card className="flex flex-col items-center text-center p-6 border border-gray-200 shadow-sm hover:shadow-md transition-all duration-300 bg-white h-full">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mb-4">
              <Users className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-primary mb-3">Step 2: Expert Tutor Match</h3>
            <p className="text-sm text-text-secondary">
              Get paired with a top AP tutor who fits your subject needs and learning style.
            </p>
          </Card>

          {/* Step 3 */}
          <Card className="flex flex-col items-center text-center p-6 border border-gray-200 shadow-sm hover:shadow-md transition-all duration-300 bg-white h-full">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mb-4">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-primary mb-3">Step 3: First Lesson, Real Results</h3>
            <p className="text-sm text-text-secondary">
              Jumpstart your AP success with an engaging, structured first session.
            </p>
          </Card>
        </div>

        <div className="flex justify-center mt-8 md:mt-10">
          <Button className="w-full sm:w-auto inline-flex h-10 items-center justify-center rounded-md bg-primary px-6 text-base font-medium text-white shadow-md hover:bg-primary-dark transition-all duration-300 max-w-xs">
            Get Started
          </Button>
        </div>
      </div>
    </section>
  )
}
