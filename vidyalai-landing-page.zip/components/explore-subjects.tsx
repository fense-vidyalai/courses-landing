import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight, MicroscopeIcon, Atom, FlaskRoundIcon as Flask } from "lucide-react"
import { SectionHeader } from "./section-header"

export function ExploreSubjects() {
  return (
    <section className="w-full py-12 md:py-16 lg:py-20 bg-white border-t border-gray-100" id="subjects">
      <div className="container px-4 md:px-6">
        <SectionHeader badge="AP Subjects" title="Explore Subjects" />

        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Link href="/subjects/ap-biology" className="group">
            <Card className="overflow-hidden transition-all duration-300 hover:shadow-hover border-gray-200 h-full transform hover:-translate-y-2">
              <div className="h-40 md:h-48 bg-primary/10 flex items-center justify-center p-6">
                <div className="rounded-full bg-white p-3 md:p-4 shadow-soft group-hover:shadow-md transition-all duration-300">
                  <MicroscopeIcon className="h-8 w-8 md:h-10 md:w-10 text-primary" />
                </div>
              </div>
              <CardContent className="p-6 md:p-8 flex flex-col h-[calc(100%-10rem)] md:h-[calc(100%-12rem)]">
                <h3 className="text-xl md:text-2xl font-bold text-black mb-3 group-hover:text-primary transition-colors">
                  AP Biology
                </h3>
                <p className="text-sm md:text-base text-text-secondary mb-4 flex-grow">
                  Help your child master complex biological concepts and excel in their AP Biology exam with our expert
                  tutors.
                </p>
                <div className="flex items-center text-primary font-medium">
                  <span>Learn More</span>
                  <ArrowRight className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/subjects/ap-physics" className="group">
            <Card className="overflow-hidden transition-all duration-300 hover:shadow-hover border-gray-200 h-full transform hover:-translate-y-2">
              <div className="h-40 md:h-48 bg-primary/10 flex items-center justify-center p-6">
                <div className="rounded-full bg-white p-3 md:p-4 shadow-soft group-hover:shadow-md transition-all duration-300">
                  <Atom className="h-8 w-8 md:h-10 md:w-10 text-primary" />
                </div>
              </div>
              <CardContent className="p-6 md:p-8 flex flex-col h-[calc(100%-10rem)] md:h-[calc(100%-12rem)]">
                <h3 className="text-xl md:text-2xl font-bold text-black mb-3 group-hover:text-primary transition-colors">
                  AP Physics
                </h3>
                <p className="text-sm md:text-base text-text-secondary mb-4 flex-grow">
                  Our tutors help your child understand complex physics principles and problem-solving techniques for AP
                  Physics success.
                </p>
                <div className="flex items-center text-primary font-medium">
                  <span>Learn More</span>
                  <ArrowRight className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/subjects/ap-chemistry" className="group">
            <Card className="overflow-hidden transition-all duration-300 hover:shadow-hover border-gray-200 h-full transform hover:-translate-y-2">
              <div className="h-40 md:h-48 bg-primary/10 flex items-center justify-center p-6">
                <div className="rounded-full bg-white p-3 md:p-4 shadow-soft group-hover:shadow-md transition-all duration-300">
                  <Flask className="h-8 w-8 md:h-10 md:w-10 text-primary" />
                </div>
              </div>
              <CardContent className="p-6 md:p-8 flex flex-col h-[calc(100%-10rem)] md:h-[calc(100%-12rem)]">
                <h3 className="text-xl md:text-2xl font-bold text-black mb-3 group-hover:text-primary transition-colors">
                  AP Chemistry
                </h3>
                <p className="text-sm md:text-base text-text-secondary mb-4 flex-grow">
                  Your child will build a strong foundation in chemical principles and laboratory techniques for AP
                  Chemistry success.
                </p>
                <div className="flex items-center text-primary font-medium">
                  <span>Learn More</span>
                  <ArrowRight className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        <div className="flex justify-center mt-12 md:mt-16">
          <Button className="w-full sm:w-auto inline-flex h-12 items-center justify-center rounded-md bg-primary px-6 md:px-8 text-base font-medium text-white shadow-md hover:bg-primary-dark transition-all duration-300 transform hover:scale-105 max-w-xs">
            Request Lesson
          </Button>
        </div>
      </div>
    </section>
  )
}
